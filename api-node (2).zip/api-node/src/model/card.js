const { Sequelize, DataTypes } = require('sequelize')
const sequelize = require('../config/database')

const Card = sequelize.define('Cards',
    {
        id:{
            type: DataTypes.UUIDV4,
            primaryKey: true
        },
        cardname:{
            type: DataTypes.STRING,
            allowNull: false
        },
        carsdesc: {
            type: DataTypes.STRING,
            allowNull: false
        },
        cardatk: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        carddef: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        cardlvl: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        cardcost: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        cardimg: {
            type: DataTypes.STRING,
            allowNull: false
        },
    }
)

module.exports = Card;