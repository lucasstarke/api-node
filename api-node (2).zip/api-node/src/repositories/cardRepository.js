const Card = require('../model/card');

class CardRepository {
    async createCard(card){
        return await Card.create(card);
    }

    async findAll(){
        return await Card.findAll();
    }

    async findByCardName(cardname){
        return await Card.findOne({ where: {cardname}})
    }
    async findByCardName(cardatk){
        return await Card.findOne({ where: {cardatk}})
    }
    async findByCardName(carddef){
        return await Card.findOne({ where: {carddef}})
    }
    async findByCardName(cardlvl){
        return await Card.findOne({ where: {cardlvl}})
    }
    async findByCardName(cardcost){
        return await Card.findOne({ where: {cardcost}})
    }
    async findByCardName(cardimg){
        return await Card.findOne({ where: {cardimg}})
    }
    async findByCardName(carddesc){
        return await Card.findOne({ where: {carddesc}})
    }

    async delete(id){
        await Card.destroy({where: {id}})
    }
}

module.exports = new CardRepository();