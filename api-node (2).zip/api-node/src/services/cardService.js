const bcrypt = require('bcrypt');
const userRepository = require('../repositories/cardRepository');
const { v4: UUIDV4 } = require('uuid')
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class CardService{
    async getAll(){
        return cardRepository.findAll();
    }

    async getByCardName(cardname){
        return cardRepository.findByCardName(cardname);
    }

    async register(cardname, cardatk, carddef, cardlvl, cardcost, cardimg, carddesc){
        if(cardatk <1||cardatk>10){
            throw new Error('Ataque Inválido');
        }
        if(cardcost <1||cardcost>10){
            throw new Error('Custo Inválido');
        }
        if(carddef <1||carddef>10){
            throw new Error('Defesa Inválida');
        }
        if(cardname === ""){
            throw new Error('Nome Inválido');
        }
        if(cardimg.length < 11||cardimg.length > 200){
            throw new Error('Url Inválida');
        }
        if(cardlvl <1||cardlvl>5){
            throw new Error('Level Inválido');
        }
        if(carddesc.length<1||carddesc.length>250){
            throw new Error('Descrição Inválida');
        }
        const card = await this.getByCardName(cardname);
        if(card){
            throw new Error('Nome indisponivel');
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await cardRepository.createCard({
            id,
            cardname,
            cardatk,
            carddef,
            cardlvl,
            cardcost,
            cardimg,
            carddesc,
        });
    }

    async login(cardname,cardatk, carddef, cardlvl, cardcost, cardimg, carddesc){
        const cardname = await this.getByCardName(cardname);
        const cardatk = await this.getByCardName(cardatk);
        const carddef = await this.getByCardName(carddef);
        const cardlvl = await this.getByCardName(cardlvl);
        const cardcost = await this.getByCardName(cardcost);
        const cardimg = await this.getByCardName(cardimg);
        const carddesc = await this.getByCardName(carddesc);
        
        if(!card){
            throw new Error('Paramentros Inválidos');
        }
        
    }

    async delete(cardname){
        const card = await this.getByCardName(cardname);
        console.log(cardname);
        if(!cardname){
            throw new Error('Nome inválido');
        }
        cardRepository.delete(cardname.id);
    }
}

module.exports = new CardService();